// Sample file showing how to define the name of this machine for performance tests.
// Choose a unique name for your development machine, rename this file to be called
// "MachineName.js" and then you can enter the expected times for performance tests
// using your unique machine name into src/test/ExpectedPerf.js.
window.MYPHYSICSLAB_MACHINE_NAME = 'Isaac_Newton_MacBookPro2013';
